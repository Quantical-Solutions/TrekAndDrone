<div id='bandeaucookies'>
	<div>
		<div>
		Ce site utilise des cookies pour améliorer votre navigation. En continuant votre navigation, vous en acceptez l'utilisation. 
 			<a href='javascript:void(0);' onclick='PonerCookie();'><b>OK</b></a>
 			<a href='https://www.trekandrone.com/cookies' target='_blank'>En savoir plus</a>
		</div>
   </div>
</div>